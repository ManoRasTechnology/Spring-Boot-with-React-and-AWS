import logo from './logo.svg';
import './App.css';

import React, {components} from 'react';
import { Switch, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'

import ListUsers from './components/list-users.component';
import Home from './components/home.component';
import AddUser from './components/add-user.component';

function App() {
  return (
    <div className="App">
      <header className="App-header1">
        <div class="page-header text-center">
          <h2>User Registration App</h2>
        </div>
      </header>
      <br/>
      <div class="container-fluid">
        <nav class="navbar  bg-primary  justify-content-center">
            <div class="col-sm"></div>
            <a href="/"
              class="col-sm btn btn-outline-light"
              role="button">
              Home
            </a>
            <div class="col-sm"></div>
            <a href="/list-all-users"
              class="col-sm btn btn-outline-light"
              role="button">
              List All Users
            </a>
            <div class="col-sm"></div>
            <a href="/add-user"
              class="col-sm btn btn-outline-light"
              role="button">
              Add User
            </a>
            <div class="col-sm"></div>
        </nav>
        <br/>
        <div className="container mt-3">
          <Switch>
            <Route exact path={["/"]} component={Home} />
            <Route exact path={["/list-all-users"]} component={ListUsers} />
            <Route exact path={["/add-user"]} component={AddUser} />
          </Switch>
        </div>
      </div>
    </div>
  );
}

export default App;